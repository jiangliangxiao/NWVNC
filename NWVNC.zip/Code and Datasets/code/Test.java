package ceka.NWVNC;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import ceka.consensus.MajorityVote;
import ceka.converters.FileLoader;
import ceka.converters.FileSaver;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Worker;
import ceka.lhr.noise.CENC;
import ceka.lhr.noise.CTNC;
import ceka.noise.ClassificationFilter;
import ceka.noise.PolishingLabels;
import ceka.noise.SelfTrainCorrection;
import ceka.noise.avnc.AdaptiveClassificationFilter;
import ceka.noise.avnc.VoteCorrection;
import ceka.noise.avnc.WorkerStat;
import ceka.noise.clustering.ClusterCorrection;
import ceka.simulation.MockWorker;
import ceka.simulation.SingleQualLabelingStrategy;
import ceka.utils.DatasetManipulator;
import ceka.utils.Stochastics;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
import weka.clusterers.Clusterer;
import weka.clusterers.SimpleKMeans;

public class Test {
	private static String[] dataSetName = {"anneal","audiology","autos","balance-scale","biodeg",
		"breast-cancer","breast-w","car","credit-a","credit-g","diabetes","heart-c","heart-h",
		"heart-statlog","hepatitis","horse-colic","hypothyroid","ionosphere","iris","kr-vs-kp",
		"labor","letter","lymph","mushroom","segment","sick","sonar","spambase","tic-tac-toe",
		"vehicle","vote","vowel","waveform","zoo"};
//	private static String[] dataSetName = {"leaves6","music_genere"};

	// read the synthetic dataset
	public Dataset readDataset(int m_choose) throws Exception{
		String dataDir = "F:\\Code\\cekaspace\\MyCekaApp\\data\\synthetic\\";
		String arffPath= dataDir + dataSetName[m_choose]+"\\"+dataSetName[m_choose]+".arff";
		Dataset dataset = FileLoader.loadFile(arffPath);
		return dataset;
	}

	// read the real-world dataset
	public Dataset readRealDataset(int m_choose) throws Exception{	
		String dataDir = "F:\\Code\\cekaspace\\MyCekaApp\\data\\real-world\\";
		String arffXPath = dataDir + dataSetName[m_choose] + "\\" + dataSetName[m_choose] + ".arffx";
		String arffPath = dataDir + dataSetName[m_choose] + "\\" + dataSetName[m_choose] + ".arff";
		String goldPath = dataDir + dataSetName[m_choose] + "\\" + dataSetName[m_choose] + ".gold.txt";
		String responsePath = dataDir + dataSetName[m_choose] + "\\" + dataSetName[m_choose] + ".response.txt";
			
		Dataset dataset;
		try {
			dataset = FileLoader.loadFileX(responsePath, goldPath, arffXPath);
		} catch (Exception e) {
			dataset = FileLoader.loadFile(responsePath, goldPath, arffPath);
		}
	
		return dataset;
	}
		
	public Dataset copyDataset(Dataset dataset) throws Exception{
		Dataset newdataset = dataset.generateEmpty();
		for(int i = 0;i < dataset.getCategorySize();i++) {
			Category cate = dataset.getCategory(i);
			newdataset.addCategory(cate);
		}
		for(int i = 0;i < dataset.getExampleSize();i++) {
			Example e = dataset.getExampleByIndex(i);
			newdataset.addExample(e);
				
			for(int j = 0;j < e.getWorkerIdList().size();j++) {
				String wID = e.getWorkerIdList().get(j);
				Worker worker = newdataset.getWorkerById(wID);
				if(worker == null) {
					newdataset.addWorker(worker = new Worker(wID));
				}
			}
		}
		return newdataset;
	}
	
	public static void simulate(Dataset dataset,int numOfWorkers,double lowQuality,double highQuality)
	{
		
		MockWorker[] mockworkers=new MockWorker[numOfWorkers];
		for(int i=0;i<numOfWorkers;i++) {
			double quality=randdouble(lowQuality, highQuality);
			SingleQualLabelingStrategy strategy=new SingleQualLabelingStrategy(quality);
			mockworkers[i]=new MockWorker(new Integer(i).toString());
			mockworkers[i].setSingleQuality(quality);
			mockworkers[i].labeling(dataset, strategy);
		}
	
	}
	
	public static double randdouble(double max, double min) {
		return (Math.random() * (max - min) + min) ;
	}
	
	public double getNoiseRatio(Dataset dataset) throws Exception{
		int count = 0;
		for(int i = 0;i < dataset.getExampleSize();i++) {
			if(dataset.getExampleByIndex(i).getIntegratedLabel().getValue() != dataset.getExampleByIndex(i).getTrueLabel().getValue()) {
				count++;
			}
		}
		return 100*(double)count/dataset.getExampleSize();
	}
	
	public static int max(int[] counts) throws Exception{
		int maxCount=counts[0];
		for(int i=0;i<counts.length;i++) {
			if(counts[i]>maxCount) maxCount=counts[i];
		}
		return maxCount;
	}
	
	public static double calculateWeight(Example example,int numOfCategories) throws Exception{
		int[] counts=new int[numOfCategories];
		
		for(int i=0;i<example.getMultipleNoisyLabelSet(0).getLabelSetSize();i++)
			counts[example.getMultipleNoisyLabelSet(0).getLabel(i).getValue()]++;
		return (double)(max(counts))/(example.getMultipleNoisyLabelSet(0).getLabelSetSize());
	}
	
	public static double[] calculateWeights(Dataset dataset) throws Exception{
		double[] weights=new double[dataset.getExampleSize()];
		
		for(int i=0;i<dataset.getExampleSize();i++) {
			Example example=dataset.getExampleByIndex(i);
			weights[i]=calculateWeight(example,dataset.getCategorySize());  //weighti = maxCounti / SumCounti
		}
		return weights;
	}

	public static void main(String[] args){
		double noiseRatio_MV=0.0;
		double noiseRatio_PL=0.0;
		double noiseRatio_STC=0.0;
		double noiseRatio_CC=0.0;
		double noiseRatio_AVNC=0.0;
		double noiseRatio_CENC=0.0;
		double noiseRatio_NWVNC=0.0;
		double noiseRatio_CTNC=0.0;
		
		double meanNoiseRatio_MV=0.0;
		double meanNoiseRatio_PL=0.0;
		double meanNoiseRatio_STC=0.0;
		double meanNoiseRatio_CC=0.0;
		double meanNoiseRatio_AVNC=0.0;
		double meanNoiseRatio_CENC=0.0;
		double meanNoiseRatio_CTNC=0.0;
		double meanNoiseRatio_NWVNC=0.0;
		
		try {
			String resultPath="F:\\Code\\cekaspace\\MyCekaApp\\result\\result.txt";
			FileOutputStream f=new FileOutputStream(new File(resultPath));
			PrintStream result=new PrintStream(f);
			result.format("%-20s %-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s", "Dataset","MV","PL","STC","CC","AVNC","CENC","CTNC","NWVNC");
			result.println();
			
			for(int i=0;i<dataSetName.length;i++){
				double tempNoiseRatio_MV=0.0;
				double tempNoiseRatio_PL=0.0;
				double tempNoiseRatio_STC=0.0;
				double tempNoiseRatio_CC=0.0;
				double tempNoiseRatio_AVNC=0.0;
				double tempNoiseRatio_CENC=0.0;
				double tempNoiseRatio_NWVNC=0.0;
				double tempNoiseRatio_CTNC=0.0;
				
				for(int m = 0;m < 10;m++) {
					
					Test experiment=new Test();
//					Dataset dataset=experiment.readRealDataset(i);
					Dataset dataset=experiment.readDataset(i);
					experiment.simulate(dataset, 7,0.55,0.75);
				
					MajorityVote mv=new MajorityVote();
					mv.doInference(dataset);
					noiseRatio_MV=experiment.getNoiseRatio(dataset);
				
					//PL
					Dataset tempDataset1=experiment.copyDataset(dataset);
					Classifier classifier1=new J48();
					PolishingLabels pl=new PolishingLabels(classifier1);
					Dataset dataset_corrected_pl=pl.polishLabels(tempDataset1);
					noiseRatio_PL=experiment.getNoiseRatio(dataset_corrected_pl);
					System.out.println("PL Completed!");
				
					//STC
					Dataset tempDataset2=experiment.copyDataset(dataset);
					Classifier[] classifiers2=new Classifier[1];
					classifiers2[0]=new J48();
					ClassificationFilter cf1=new ClassificationFilter(10);
					cf1.filterNoise(tempDataset2, classifiers2);
					Dataset cleanSet1=cf1.getCleansedDataset();
					Dataset noiseSet1=cf1.getNoiseDataset();
				
					Dataset[] tempdata=new Dataset[2];
					SelfTrainCorrection stc=new SelfTrainCorrection(cleanSet1,noiseSet1,0.8);
					Classifier classifier3=new J48();
					tempdata=stc.correction(classifier3);
					DatasetManipulator.addAllExamples(tempdata[0], tempdata[1]);
					noiseRatio_STC=experiment.getNoiseRatio(tempdata[0]);
					System.out.println("STC Completed!");
				
					//CC
					Dataset tempDataset3=experiment.copyDataset(dataset);
					int numClusters=10;
					Clusterer[] clusterers=new Clusterer[numClusters];
					for(int c=0;c<numClusters;c++){
						int k=(int)(((double)(c+1)/(double)(numClusters))*(tempDataset3.getExampleSize()/2.0));
						if(c==0) k=k+2;
						SimpleKMeans simpleKMeans=new SimpleKMeans();
						simpleKMeans.setMaxIterations(200);
						simpleKMeans.setNumClusters(k);
						clusterers[c]=simpleKMeans;
					}
					
					String tempPath="F:\\Code\\cekaspace\\MyCekaApp\\data\\output\\"+dataSetName[i]+m+".arff";
					FileSaver.saveDatasetArff(tempDataset3, tempPath);
					ClusterCorrection cc=new ClusterCorrection(tempDataset3,tempPath,clusterers);
					Dataset dataset_corrected_cc=cc.correction();
					noiseRatio_CC=experiment.getNoiseRatio(dataset_corrected_cc);
					System.out.println("CC Completed!");
					
					// AVNC
					Dataset tempDataset4=experiment.copyDataset(dataset);
					
					WorkerStat workerStat=new WorkerStat();
					double estimatedMeanProb=workerStat.calculateEstimatedMeanAcc(dataset);
					double integratedCorrectProb=Stochastics.binomialIntegration(9, estimatedMeanProb);
					int nfold=10;
					int nModel=5;
					AdaptiveClassificationFilter acf=new AdaptiveClassificationFilter(nfold,nModel);
					acf.setMinEstimatedNoiseProportion(1-integratedCorrectProb);
					acf.setMaxEstimatedNoiseProportion(1-estimatedMeanProb);
					
					Classifier[] classifiers4=new Classifier[5];
					for(int k=0;k<5;k++)
						classifiers4[k]=new J48();
					acf.filterNoise(tempDataset4, classifiers4);
					Dataset cleanSet2=acf.getCleansedDataset();
					Dataset noiseSet2=acf.getNoiseDataset();
					Dataset[] highDatasets=acf.getHighQualityDatasets();
					
					VoteCorrection corrector=new VoteCorrection();
					corrector.correct(noiseSet2, highDatasets, classifiers4, (int)(highDatasets.length*0.5));
					for(int k=0;k<noiseSet2.getExampleSize();k++)
						cleanSet2.addExample(noiseSet2.getExampleByIndex(k));
					noiseRatio_AVNC=experiment.getNoiseRatio(cleanSet2);
					System.out.println("AVNC Completed!");
				
					//CENC
					Dataset tempDataset5=experiment.copyDataset(dataset);
					CENC cenc=new CENC(10,0.1);
					Classifier classifier5=new J48();
					Dataset dataset_corrected_cenc=cenc.cenc(tempDataset5, classifier5);
					noiseRatio_CENC=experiment.getNoiseRatio(dataset_corrected_cenc);
					System.out.println("CENC Completed!");
				
					// CTNC
					Dataset tempDataset8 = experiment.copyDataset(dataset);
					double[] weights = calculateWeights(tempDataset8);
					for(int k = 0; k < tempDataset8.getExampleSize(); k++)
						tempDataset8.getExampleByIndex(k).setWeight(weights[k]);
				
					Classifier[] classifiers44 = new Classifier[1];
					classifiers44[0] = new J48();
					ClassificationFilter cf44 = new ClassificationFilter(10);
					cf44.filterNoise(tempDataset8, classifiers44);
					Dataset cleanSet44 = cf44.getCleansedDataset();
					Dataset noiseSet44 = cf44.getNoiseDataset();
				
					CTNC ctnc = new CTNC();
					Dataset dataset_corrected_ctnc = ctnc.noiseCorrection(cleanSet44, noiseSet44, 7, 0.8);
					noiseRatio_CTNC = experiment.getNoiseRatio(dataset_corrected_ctnc);
					System.out.println("CTNC Completed!");
				
				
					//NWVNC
					Dataset tempDataset6=experiment.copyDataset(dataset);
					NWVNC newnc = new NWVNC();
					Dataset dataset_corrected_newnc = newnc.nwvnc(tempDataset6);
					noiseRatio_NWVNC = experiment.getNoiseRatio(dataset_corrected_newnc);
					System.out.println("newNC Completed");

				
					tempNoiseRatio_MV+=noiseRatio_MV;
					tempNoiseRatio_PL+=noiseRatio_PL;
					tempNoiseRatio_STC+=noiseRatio_STC;
					tempNoiseRatio_CC+=noiseRatio_CC;	
					tempNoiseRatio_AVNC+=noiseRatio_AVNC;
					tempNoiseRatio_CENC+=noiseRatio_CENC;
					tempNoiseRatio_CTNC+=noiseRatio_CTNC;
					tempNoiseRatio_NWVNC+=noiseRatio_NWVNC;
					System.out.println("The"+m+"time completed");
				}
				tempNoiseRatio_MV/=10;
				tempNoiseRatio_PL/=10;
				tempNoiseRatio_STC/=10;
				tempNoiseRatio_CC/=10;	
				tempNoiseRatio_AVNC/=10;
				tempNoiseRatio_CENC/=10;
				tempNoiseRatio_CTNC/=10;
				tempNoiseRatio_NWVNC/=10;
				
				
				meanNoiseRatio_MV+=tempNoiseRatio_MV;
				meanNoiseRatio_PL+=tempNoiseRatio_PL;
				meanNoiseRatio_STC+=tempNoiseRatio_STC;
				meanNoiseRatio_CC+=tempNoiseRatio_CC;
				meanNoiseRatio_AVNC+=tempNoiseRatio_AVNC;
				meanNoiseRatio_CENC+=tempNoiseRatio_CENC;
				meanNoiseRatio_CTNC+=tempNoiseRatio_CTNC;
				meanNoiseRatio_NWVNC+=tempNoiseRatio_NWVNC;
		

				
				result.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", dataSetName[i],tempNoiseRatio_MV,tempNoiseRatio_PL,tempNoiseRatio_STC,tempNoiseRatio_CC,tempNoiseRatio_AVNC,tempNoiseRatio_CENC,tempNoiseRatio_CTNC,tempNoiseRatio_NWVNC);
				result.println();
				System.out.println(dataSetName[i]+" complete!");
			}

			
			
			meanNoiseRatio_MV/=dataSetName.length;
			meanNoiseRatio_PL/=dataSetName.length;
			meanNoiseRatio_STC/=dataSetName.length;
			meanNoiseRatio_CC/=dataSetName.length;

			meanNoiseRatio_AVNC/=dataSetName.length;
			meanNoiseRatio_CENC/=dataSetName.length;
			meanNoiseRatio_CTNC/=dataSetName.length;
			meanNoiseRatio_NWVNC/=dataSetName.length;
			
			result.format("%-20s %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f %-10.2f", "Mean",meanNoiseRatio_MV,meanNoiseRatio_PL,meanNoiseRatio_STC,meanNoiseRatio_CC,meanNoiseRatio_AVNC,meanNoiseRatio_CENC,meanNoiseRatio_CTNC,meanNoiseRatio_NWVNC);
			result.println();
			result.close();
			
			System.out.println("Complete!!!");
			
		}catch(Exception e){
			System.out.println(e);
		}
	}

}
